<?php
 
defined('_JEXEC') or die;
 
class modNewsHelper
{
	public static function getNews()
	{
		//подключаемся к базе данных
		/* $app	= JFactory::getApplication();
		$db = JFactory::getDbo();
 
		//здесь какие-то действия и запросы к базе данных
		...
		//возвращаем результат
		return $rows; */
		echo 'test';
	}
}